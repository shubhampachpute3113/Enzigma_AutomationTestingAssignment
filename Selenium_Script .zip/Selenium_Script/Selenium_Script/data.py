url = "https://app-staging.nokodr.com/"
signup_data = {
    "email": "shubhampachpute29@gmail.com",
    "password": "Password@12",
    "confirm_password": "Password@12",
    "fname_val":"Shubham",
    "lname_val":"Pachpute",
    "email_invalid_format":"shubhampachpute29.gmail.com",
    "confirm_password_mismatch":"Password@21",
    "fname_special_char":"Shubh@m"
}

login_data = {
    "email": "shubhampachpute29@gmail.com",
    "password": "Password@12",
    "invalid_email":"shubhampachpute29.gmail.com",
    "invalid_password":"abc1",
    "special_char": "shubhampach$%%%$!3.gmail.com"
}

forgot_pwd_data = {
      "email": "shubhampachpute29@gmail.com",
      "email_invalid_format": "shubhampach$%%%$!3.gmail.com",
      "email_non_registered":"Shubhu1234@gmail.com"
}